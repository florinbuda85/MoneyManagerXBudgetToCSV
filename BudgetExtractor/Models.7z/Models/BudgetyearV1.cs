﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BudgetExtractor.Models
{
    public partial class BudgetyearV1
    {
        public long Budgetyearid { get; set; }
        public string Budgetyearname { get; set; }
    }
}
