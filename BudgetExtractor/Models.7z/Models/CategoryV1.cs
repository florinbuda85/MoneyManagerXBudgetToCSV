﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BudgetExtractor.Models
{
    public partial class CategoryV1
    {
        public long Categid { get; set; }
        public string Categname { get; set; }
    }
}
